public class Main {
    public static void main(String[] args) {
        int num = 579;
        System.out.println(num/100 +"," + num/10%10 + "," + num%10 + "," );
    }
}